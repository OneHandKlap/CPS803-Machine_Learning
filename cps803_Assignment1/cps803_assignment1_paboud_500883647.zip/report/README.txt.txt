Hello CPS803 TA

I have completed my report for assignment 1 in two parts. You will find a jupyter notebook file in each folder, you can recognize them by the .ipynb file extension.
I have also included the images for each part in a corresponding 'img' folder. Finally the calculations for Bayes theorem and 1.1 can be found in the microsoft word doc.

Please let me know if you have any trouble with this format. The python source files have also been included.

Sincerely,

P. Adam Aboud